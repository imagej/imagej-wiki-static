import ij.*;
import ij.plugin.PlugIn;
 
import net.imglib2.*;
import net.imglib2.img.*;
import net.imglib2.img.display.imagej.ImageJFunctions;
import net.imglib2.util.Util;
import net.imglib2.type.*;
import net.imglib2.type.numeric.*;
import net.imglib2.type.numeric.real.*;
import net.imglib2.view.*;

/**
 *  Compute the gradient at each pixel location in the image in N dimensions
 *  using OutOfBoundsStrategies
 */
public class ImgLib2_Gradient2 implements PlugIn
{
	public void run(String arg0)
	{
		// get the current ImageJ ImagePlus
		ImagePlus imp = WindowManager.getCurrentImage();

		// test if an image is open
		if ( imp == null )
		{
			IJ.log( "No image open" );
			return;
		}

		// wrap it into an ImgLib2 Img (no copying)
		Img<RealType> img = ImageJFunctions.wrapReal( imp );

		// test if it could be wrapped
		if ( img == null )
		{
			IJ.log( "Cannot wrap image" );
			return;
		}

		// process wrapped image with ImgLib2
		process( img );
	}

	public <T extends RealType<T>> void process( Img<T> img )
	{
		// compute the gradient on the image
		Img<T> gradient = gradient( img );

		// show the new Img that contains the gradient
		ImageJFunctions.show( gradient );
	}

	public <T extends RealType<T>> Img<T> gradient( Img< T > img )
	{
		// create a new ImgLib2 image of same type & dimensions
		ImgFactory<T> imgFactory = img.factory();
		Img<T> gradientImg = imgFactory.create( img, img.firstElement() );
				
		// create a localizing cursor on the GradientImg, it will iterate all pixels
		// and is able to efficiently return its position at each pixel, at each
		// pixel we will compute the gradient
		Cursor<T> cursor = gradientImg.localizingCursor();

		// We extend the input image by a mirroring out of bounds strategy so
		// that we can access pixels outside of the image
		RandomAccessible<T> view = ...
		
		// instantiate a RandomAccess on the extended view, it will be used to 
		// compute the gradient locally at each pixel location
		/**
		RandomAccess<T> randomAccess = img.randomAccess();
		*/
		
		// iterate over all pixels
		while ( cursor.hasNext() )
		{
			// move the cursor to the next pixel
			cursor.fwd();

			// now we can simply remove the stupid test
			/**
			// test if we are able to compute the gradient
			boolean validPosition = true;

			for ( int d = 0; d < img.numDimensions(); ++d )
				if ( cursor.getLongPosition( d ) <= 0 || cursor.getLongPosition( d ) >= img.dimension( d ) - 1 )
					validPosition = false;

			if ( !validPosition )
				continue;
			*/
			
			// compute gradient in each dimension
			double gradient = 0;
			
			for ( int d = 0; d < img.numDimensions(); ++d )
			{
				// set the randomaccess to the location of the cursor
				randomAccess.setPosition( cursor );

				// move one pixel back in dimension d
				randomAccess.bck( d );

				// get the value 
				double v1 = randomAccess.get().getRealDouble();

				// move twice forward in dimension d, i.e.
				// one pixel above the location of the cursor
				randomAccess.fwd( d );
				randomAccess.fwd( d );

				// get the value
				double v2 = randomAccess.get().getRealDouble();

				// add the square of the magnitude of the gradient
				gradient += ((v2 - v1) * (v2 - v1))/4;
			}

			// the square root of all quadratic sums yields
			// the magnitude of the gradient at this location,
			// set the pixel value of the gradient image
			cursor.get().setReal( Math.sqrt( gradient ) );
		}

		return gradientImg;
	}
}