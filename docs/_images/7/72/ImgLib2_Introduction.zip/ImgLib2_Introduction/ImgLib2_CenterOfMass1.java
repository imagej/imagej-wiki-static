import ij.*;
import ij.plugin.PlugIn;
 
import net.imglib2.*;
import net.imglib2.img.*;
import net.imglib2.img.display.imagej.ImageJFunctions;
import net.imglib2.util.Util;
import net.imglib2.type.*;
import net.imglib2.type.numeric.*;
import net.imglib2.type.numeric.real.*;

/**
 * Compute the center of mass of the image in two dimensions (x,y)
 */
public class ImgLib2_CenterOfMass1 implements PlugIn
{
	public void run(String arg0)
	{
		// get the current ImageJ ImagePlus
		ImagePlus imp = WindowManager.getCurrentImage();

		// test if an image is open
		if ( imp == null )
		{
			IJ.log( "No image open" );
			return;
		}

		// wrap it into an ImgLib2 Img (no copying)
		Img<RealType> img = ImageJFunctions.wrapReal( imp );

		// test if it could be wrapped
		if ( img == null )
		{
			IJ.log( "Cannot wrap image" );
			return;
		}
		// process wrapped image with ImgLib2
		process( img );
	}

	public <T extends RealType<T>> void process( Img<T> img )
	{
		// compute the threshold on the image in-place
		// (overwrite each pixel with the threshold value)
		double[] center = centerOfMass2d( img );

		// print out center of mass into the ImageJ log window
		IJ.log( "Center of mass = " + Util.printCoordinates( center ) );
	}

	public <T extends RealType<T>> double[] centerOfMass2d( Img< T > img )
	{
		// use a double array to store the center of mass (x,y)
		
		// create a LOCALIZING cursor on the Img, it will iterate all pixels
		// and is able to efficiently return its position at each pixel

		// use two double to store the sum of all locations weighted by 
		// their pixel intensities for x and y;
		
		// use a double to store the sum of all intensities

		// iterate over all pixels, get the location and intensity for each
		// pixel and sum up the product for each dimension individually

		// compute center of mass for x and y by dividing by the sum of
		// intensities

		// return the result
		return ...;
	}
}