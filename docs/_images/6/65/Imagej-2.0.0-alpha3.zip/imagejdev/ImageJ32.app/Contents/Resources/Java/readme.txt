Java libraries are in the jar folder of the ImageJ distribution.
